from django.apps import AppConfig


class BasiccrudConfig(AppConfig):
    name = 'basicCRUD'
