from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView 
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .models import Contact


class ContactList(ListView): 
    model = Contact
	
class ContactDetail(DetailView): 
    model = Contact
	
class ContactCreate(CreateView): 
	model = Contact
	fields = ['name','email','address','phone']
	success_url = reverse_lazy('contact_list')
	
class ContactUpdate(UpdateView): 
	model = Contact
	fields = ['name','email','address','phone']
	success_url = reverse_lazy('contact_list')
	
class ContactDelete(DeleteView): 
	model = Contact
	success_url = reverse_lazy('contact_list')
	
	